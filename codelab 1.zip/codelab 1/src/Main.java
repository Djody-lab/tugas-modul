import java.util.Scanner;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan nama Anda: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan jenis kelamin (L/P): ");
        char jenisKelamin = scanner.next().charAt(0);

        String jenisKelaminStr;
        if (jenisKelamin == 'L' || jenisKelamin == 'l') {
            jenisKelaminStr = "Laki-laki";
        } else if (jenisKelamin == 'P' || jenisKelamin == 'p') {
            jenisKelaminStr = "Perempuan";
        } else {
            jenisKelaminStr = "Gak valid";
        }

        System.out.print("Masukkan tahun lahir Anda: ");
        int tahunLahir = scanner.nextInt();

        scanner.close();

        int tahunIni = LocalDate.now().getYear();
        int umur = tahunIni - tahunLahir;

        System.out.println("\n=== Data Diri ===");
        System.out.println("Nama         : " + nama);
        System.out.println("Jenis Kelamin: " + jenisKelaminStr);
        System.out.println("Umur         : " + umur + " tahun");
    }
}
